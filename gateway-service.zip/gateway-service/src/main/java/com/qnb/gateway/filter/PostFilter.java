package com.qnb.gateway.filter;

import java.nio.charset.StandardCharsets;

import org.reactivestreams.Publisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferFactory;
import org.springframework.core.io.buffer.DefaultDataBuffer;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.http.server.reactive.ServerHttpResponseDecorator;
import org.springframework.web.server.ServerWebExchange;


import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
public class PostFilter implements GlobalFilter,Ordered{
	
	
	@Override
	public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
		log.info("inside postAuth filter ....");
//		String path = exchange.getRequest().getPath().toString();
		//ServerHttpRequest request = exchange.getRequest();
		ServerHttpResponse response = exchange.getResponse();
//        DataBufferFactory dataBufferFactory = response.bufferFactory();
//		getUser(response,chain);
//		Mono<WebSession> session = exchange.getSession();
		//log.info("session value:{}",session);
	    return chain.filter(exchange).then(Mono.fromRunnable(()-> {
				            log.info("Global Post-filter executed...",response.getStatusCode());
				            response.getHeaders().forEach((key,value) ->{
				            	log.info("Header :{}",key,value);
				            });
		        }));
//	    ServerHttpResponseDecorator decoratedResponse = getDecoratedResponse(path, response, request, dataBufferFactory);
//        return chain.filter(exchange.mutate().response(decoratedResponse).build());
	}
	 
	public ServerHttpResponseDecorator getDecoratedResponse(String path, ServerHttpResponse response,
			ServerHttpRequest request, DataBufferFactory dataBufferFactory) {
		return new ServerHttpResponseDecorator(response) {
            @Override
            public Mono<Void> writeWith(final Publisher<? extends DataBuffer> body) {

                if (body instanceof Flux) {

                    Flux<? extends DataBuffer> fluxBody = (Flux<? extends DataBuffer>) body;

                    return super.writeWith(fluxBody.buffer().map(dataBuffers -> {

                        DefaultDataBuffer joinedBuffers = new DefaultDataBufferFactory().join(dataBuffers);
                        byte[] content = new byte[joinedBuffers.readableByteCount()];
                        joinedBuffers.read(content);
                         String responseBody = new String(content, StandardCharsets.UTF_8);//MODIFY RESPONSE and Return the Modified response
                        log.debug("requestId: {}, method: {}, url: {}, \nresponse body :{}", request.getId(), request.getMethodValue(), request.getURI(), responseBody);
                        return dataBufferFactory.wrap(responseBody.getBytes());
                    })).onErrorResume(err -> {
                        log.error("error while decorating Response: {}",err.getMessage());
                        return Mono.empty();
                    });
                }
                return super.writeWith(body);
            }	
        };
	}

	private void getUser(ServerHttpResponse response, GatewayFilterChain chain) {
//        if(GatewayConstant.GET_USER_URL.equals(request.getURI())) {
//        	log.info("request body :{} ,:{}");
//        	
//        }
		
	}

	@Override
	public int getOrder() {
		return 3;
	}
 
}
