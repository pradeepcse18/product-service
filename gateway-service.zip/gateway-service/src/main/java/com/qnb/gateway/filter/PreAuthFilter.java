package com.qnb.gateway.filter;

import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import com.qnb.gateway.constant.GatewayConstant;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
public class PreAuthFilter implements GlobalFilter,Ordered{
	
	
	@Override
	public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
		
		log.info("inside preAuth filter ....");
		//ServerHttpRequest request = exchange.getRequest();
		log.info("session:{}",exchange.getSession());
		//userService
		//getUser(request,chain);
		ServerHttpRequest request = exchange.getRequest()
                .mutate()
                .header("xyz", "xsde")
                .build();
        return chain.filter(exchange.mutate().request(request).build());
	}

	private void getUser(ServerHttpRequest request, GatewayFilterChain chain) {
        if(GatewayConstant.GET_USER_URL.equals(request.getPath().toString())) {
        	var reqBody = request.getBody();
        	log.info("request body :{} ,:{}",reqBody);
        	
        }
		
	}

	@Override
	public int getOrder() {
		return -2;
	}

}
