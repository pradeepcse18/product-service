package com.qnb.gateway.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.qnb.gateway.filter.PostFilter;
import com.qnb.gateway.filter.PreAuthFilter;

@Configuration
public class GatewayConfig {

	@Bean
	public PreAuthFilter preAuthFilter() {
		return new PreAuthFilter();
	}
	
	@Bean
	public PostFilter postFilter() {
		return new PostFilter();
	}
}
