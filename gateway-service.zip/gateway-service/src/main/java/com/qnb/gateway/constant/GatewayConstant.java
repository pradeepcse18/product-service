package com.qnb.gateway.constant;

public class GatewayConstant {

	public static final String GET_USER_URL = "/users/get";

}
