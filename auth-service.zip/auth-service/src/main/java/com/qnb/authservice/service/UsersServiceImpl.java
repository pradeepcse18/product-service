package com.qnb.authservice.service;


import java.util.*;


import org.springframework.stereotype.Service;

import com.qnb.authservice.dto.UserDto;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UsersServiceImpl {


	public List<String> getUser() {
		List<String> lst = new ArrayList<>( Arrays.asList("test",
                "for",
                "microservice"));
		Collections.reverse(lst);
		return lst;
	}

	public Map<String, String> getUserId() {
		Map<String,String> response = new HashMap<>();
		response.put("id", "100");
		return response;
	}

	public UserDto getUserDetail() {
		return null;
	}

}
