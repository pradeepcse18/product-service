package com.qnb.authservice.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.qnb.authservice.dto.UserDto;
import com.qnb.authservice.service.UsersServiceImpl;



@RestController
@Transactional
@Validated
@RequestMapping("/users")
@CrossOrigin(origins = "*", allowedHeaders = "*", maxAge = 360000)
public class UsersController {

	@Autowired
	private UsersServiceImpl usersService;

	@PostMapping("/get")
	public List<String> saveUser(@RequestBody Map<String,String> reqBody){
		return usersService.getUser();
	}

	@PostMapping("/get/id")
	public Map<String,String> getId(){
		return usersService.getUserId();
	}
	
	@PostMapping("/get/user")
	public UserDto getUserDetail(){
		return usersService.getUserDetail();
	}
}
