package com.qnb.test.productservice.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/product")
public class ProductController {

	@PostMapping("/get")
	public List<String> getProduct(){
		List<String> productList = new ArrayList<String>();
		productList.add("Laptop");
		return productList;
	}
}
